# CS4486 冰山分类 · 最终提交交接包

对应提交：**version19**（Private `0.08708` / Public `0.10724`）。
该提交在比赛截止之后提交，**没有正式排名**，两个分数只是 Kaggle 返回的数值。

---

## 一、目录

| 目录 | 内容 | 文件数 |
|---|---|---|
| `01_submission/` | `version19.csv` 提交文件 + `version19.json` 生成清单（含 sha256、系数、测试集统计） | 2 |
| `02_oof/` | `oof_version19.csv` 每行折外概率；`oof_summary.json` 每折系数与分数 | 2 |
| `03_weights/` | 七个成员的 5 折检查点、逐折指标、训练曲线、软标签；`teachers/` 放教师成员与集成 | 191 |
| `04_configs/` | `folds.csv` 固定五折、`validation.json` 折定义、`members.csv` 成员配置 | 3 |
| `05_code/` | `src/` 与 `work/` 全部脚本、`VERSION.md` 代码版本 | 184 |
| `06_evidence/` | Kaggle 截图（原有文件已损坏，见该目录 README，**需要你补两张**） | 4 |

总量约 29 MB（压缩包 20 MB）。**原始数据不在包内**：`data/raw/train.json`、`test.json` 需自行下载后放到 `data/raw/`。

---

## 二、关键数字

| 项目 | 值 |
|---|---|
| 提交文件 sha256 | `48c197c8534315158402997d7449fc30b717c0468ff1424dfbe6ded59ea8c524` |
| 折外 Log Loss（含 0.90 角度缩放） | **0.098753** |
| 未缩放（仅作对照） | 0.098287 |
| 每折折外分数 | 0.078569 / 0.112742 / 0.108057 / 0.106423 / 0.087940 |
| 每折系数（图像, 精确, 近邻, 截距） | 见 `02_oof/oof_summary.json` |
| Private / Public | 0.08708 / 0.10724 |

训练集 1,604 行（851 船 / 753 冰山，133 行缺角度）；测试集 8,424 行，**无标签**。

---

## 三、成员与配置

| 成员 | 种子 | epoch | batch | lr | dropout | weight decay | 教师 | 伪标签权重 |
|---|---:|---:|---:|---:|---:|---:|---|---:|
| v5_shape | 71/83/97 | 160 | — | — | — | — | — | — |
| hp_star | 909 | 20 | 32 | 0.003 | 0.5 | 0.01 | v5_teacher | 0.25 |
| hp_b | 1201 | 20 | 32 | 0.005 | 0.5 | 0.01 | v5_teacher | 0.25 |
| hp_d | 1401 | 20 | 32 | 0.003 | 0.4 | 0.01 | v5_teacher6 | 0.25 |
| pt25a | 1401 | 20 | 32 | 0.003 | 0.4 | 0.01 | v5_teacher6 | 0.25 |
| pt25b | 2601 | 20 | 32 | 0.003 | 0.4 | 0.01 | v5_teacher6 | 0.25 |
| stu5 | 909 | 20 | 64 | 0.0015 | 0.5 | — | v5_teacher | 0.25 |

- 折种子固定 `42`（`04_configs/folds.csv`，1,604 行，321/321/321/321/320）。
- 融合：图像概率等权平均 → 折隔离两级角度先验（σ=0.012, α=0.1）→ 每折拟合一次逻辑回归（L2=1.0）→ 两个角度系数乘 0.90。
- `pt25a` / `pt25b` 把伪标签阈值从 0.03 放宽到 0.25（可用测试图约 3,500 → 6,260 行）。

---

## 四、`--angle-scale` 对应哪个脚本

**不是仓库根目录的入口脚本，而是 `work/v5_submit.py`**，该参数在此文件第 73 行定义：

```
python work/v5_predict.py --tags v5_shape hp_star hp_b hp_d pt25a pt25b stu5
python work/v5_submit.py  --tags v5_shape hp_star hp_b hp_d pt25a pt25b stu5 \
    --angle-scale 0.90 --name version19
```

它做的事：逐折拟合第二层逻辑回归后，把 `weights[1]`（精确匹配系数）与 `weights[2]`（近邻系数）
同时乘以 0.90，再用新系数重新预测并导出 CSV。
另有 `--exact-scale`，可以只缩放精确匹配那一个系数（用于 version31/32 的拆分检验）。

---

## 五、如何复核这份提交

```bash
# 1) 环境
python 3.12 / torch 2.15.0+cpu / numpy 2.5.x（CPU 即可，无需 GPU）

# 2) 准备数据与缓存
python -m src.v3.prepare --raw data/raw

# 3) 用包内权重重新预测并重建提交
python work/v5_predict.py --tags v5_shape hp_star hp_b hp_d pt25a pt25b stu5
python work/v5_submit.py  --tags v5_shape hp_star hp_b hp_d pt25a pt25b stu5 \
    --angle-scale 0.90 --name version19_check

# 4) 与包内文件逐字节比对 + 四重校验
python work/verify_submission_provenance.py version19
```

预期结果：重建的 CSV 与 `01_submission/version19.csv` **逐字节相同**，
`verify_submission_provenance.py` 输出清单哈希一致、重跑一致、检查点回放最大差异 0。

---

## 六、诚实边界（写报告时请保留）

1. 测试集没有标签，0.08708 / 0.10724 是 Kaggle 用隐藏标签算出的两个数，我们无法自行复算。
2. 迟交提交没有排名；「达到历史前五水平」只是与材料所列 0.08883 的数值比较。
3. 角度系数 0.90 是用排行榜反馈挑的，私榜的 0.00044 改善中含选择偏差；这一步是标定，不是模型能力提升。
4. 折外分数 0.098753 与私榜 0.08708 相差 0.0117，说明验证集比测试集更难，两者不能互相替代。
