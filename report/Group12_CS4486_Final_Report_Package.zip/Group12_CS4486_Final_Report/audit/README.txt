Latest evidence: version19_bundle_audit.json, version19_error_summary.json and status.json.
local_checks.json and recorded_v5_error_groups.csv concern earlier source/history, not final version19.
The final bundle source excerpt is in final_bundle_code.
Audit scripts record the executed workspace checks; rerunning requires the original handover ZIP/extraction, raw training data and matching workspace paths. They do not train models or submit to Kaggle.
The screenshot and the local CSV are linked by filename and team records, not a platform-provided hash.
