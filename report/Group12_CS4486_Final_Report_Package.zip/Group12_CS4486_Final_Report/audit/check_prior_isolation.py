import ast
import json
import textwrap
from pathlib import Path
import numpy as np

source = Path(__file__).with_name('v5_fuse_at_638f8e4.py').read_text(encoding='utf-8')
tree = ast.parse(source)
kernel = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'kernel_prior')
namespace = {'np': np}
exec(compile(ast.Module(body=[kernel], type_ignores=[]), '<reviewed kernel_prior>', 'exec'), namespace)
start = source.index('        prior = np.full(len(labels), np.nan)', source.index('def main'))
end = source.index('        image_logit =', start)
loop = textwrap.dedent(source[start:end])

def calculate(labels):
    from types import SimpleNamespace
    env = dict(namespace, labels=labels, angles=np.full(10, 40.0),
               folds=np.repeat(np.arange(5), 2), args=SimpleNamespace(sigma=.012, alpha=.1))
    exec(compile(loop, '<actual prior construction loop>', 'exec'), env)
    return env['prior']

before_labels = np.tile([0., 1.], 5)
after_labels = before_labels.copy()
after_labels[0] = 1.
before, after = calculate(before_labels), calculate(after_labels)
result = {
    'source_commit': '638f8e49264638efddbe0d32bec3ecdfd4a95c76',
    'test': 'Execute the reviewed kernel and unchanged prior-construction loop with synthetic data; no training or Kaggle data used.',
    'setup': '10 rows, 5 folds, two rows per fold, all angles 40; change only label of row 0 in validation fold 0.',
    'fold0_other_validation_row_prior_before': float(before[1]),
    'fold0_other_validation_row_prior_after': float(after[1]),
    'validation_label_changes_another_validation_feature': bool(before[1] != after[1]),
    'scope': 'Confirms isolation failure in this source loop. Does not measure score inflation or prove the exact code used for historical submissions.'
}
assert result['validation_label_changes_another_validation_feature']
Path(__file__).with_name('prior_isolation_check.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
