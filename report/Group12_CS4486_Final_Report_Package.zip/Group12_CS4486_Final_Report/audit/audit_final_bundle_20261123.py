from pathlib import Path
import ast,csv,json,hashlib,collections,shutil
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from PIL import Image

B=Path('tmp/final-bundle-20261123/CS4486_final_bundle')
R=Path('cs4486-iceberg'); O=R/'results/steps9_10_20261123'
A=R/'report/20261123/assets';O.mkdir(exist_ok=True,parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readcsv(p):return list(csv.DictReader(p.open(encoding='utf-8-sig',newline='')))
def dump(n,x):(O/n).write_text(json.dumps(x,indent=2),encoding='utf-8')
def savecsv(name,rows):
 with (O/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

train=json.loads((R/'data/raw/train.json').read_text()); raw={r['id']:r for r in train}
rows=readcsv(B/'02_oof/oof_version19.csv'); ids=np.array([r['id'] for r in rows]);n=len(rows)
y=np.array([int(r['is_iceberg']) for r in rows]);p=np.array([float(r['oof_prob']) for r in rows])
fold=np.array([int(r['fold']) for r in rows]);angle=np.array([float(r['inc_angle']) if r['inc_angle'] else np.nan for r in rows])
ip=np.array([float(r['image_prob']) for r in rows]);pr=np.array([float(r['prior']) for r in rows]);ex=np.array([int(r['exact_match']) for r in rows],bool)
mapping={r['id']:int(r['fold']) for r in readcsv(B/'04_configs/folds.csv')}
assert n==1604 and len(set(ids))==n and set(ids)==set(raw)
assert all(y[i]==raw[r]['is_iceberg'] and fold[i]==mapping[r] for i,r in enumerate(ids))
assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
expected_angle=np.array([float(raw[r]['inc_angle']) if raw[r]['inc_angle']!='na' else np.nan for r in ids])
assert np.allclose(angle,expected_angle,equal_nan=True)
sub=readcsv(B/'01_submission/version19.csv');sample=readcsv(R/'data/raw/sample_submission.csv')
assert list(sub[0])==['id','is_iceberg'] and len(sub)==8424 and len(set(r['id'] for r in sub))==8424
assert [r['id'] for r in sub]==[r['id'] for r in sample]
sp=np.array([float(r['is_iceberg']) for r in sub]);assert np.isfinite(sp).all() and ((sp>=0)&(sp<=1)).all()
manifest=json.loads((B/'01_submission/version19.json').read_text());assert sha(B/'01_submission/version19.csv')==manifest['sha256']
config=json.loads((B/'04_configs/validation.json').read_text())
assert sha(R/'data/raw/train.json')==config['train_file_sha256']
fold_hash_match=sha(B/'04_configs/folds.csv')==config['folds_sha256']
fold_lf_hash_match=hashlib.sha256((B/'04_configs/folds.csv').read_bytes().replace(b'\r\n',b'\n')).hexdigest()==config['folds_sha256']
pred=p>=.5;wrong=pred!=y;confwrong=((p>=.9)&(y==0))|((p<=.1)&(y==1))
loss=-(y*np.log(np.clip(p,1e-7,1-1e-7))+(1-y)*np.log1p(-np.clip(p,1e-7,1-1e-7)))
dist=np.full(n,np.nan)
for k in range(5):
 idx=np.where((fold==k)&np.isfinite(angle))[0];ref=angle[(fold!=k)&np.isfinite(angle)]
 dist[idx]=np.min(np.abs(angle[idx,None]-ref[None,:]),axis=1)
groups={'Exact':dist==0,'Nearby':(dist>0)&(dist<.06),'Far':dist>=.06,'Missing':~np.isfinite(angle)}
group_rows=[]
for name,mask in groups.items():
 group_rows.append(dict(group=name,rows=int(mask.sum()),errors=int(wrong[mask].sum()),confident_errors=int(confwrong[mask].sum()),log_loss=float(loss[mask].mean()),loss_share=float(loss[mask].sum()/loss.sum())))
order=np.argsort(loss)[::-1]
metrics=dict(rows=n,pooled_log_loss=float(loss.mean()),accuracy=float((~wrong).mean()),errors=int(wrong.sum()),false_iceberg=int(((pred==1)&(y==0)).sum()),missed_iceberg=int(((pred==0)&(y==1)).sum()),confident_errors=int(confwrong.sum()),per_fold={str(k):float(loss[fold==k].mean()) for k in range(5)},top25_loss_share=float(loss[order[:25]].sum()/loss.sum()),top100_loss_share=float(loss[order[:100]].sum()/loss.sum()),subgroups=group_rows,note='Descriptive audit of supplied predictions; not an independent leak-free CV estimate.')
dump('version19_error_summary.json',metrics);savecsv('version19_subgroups.csv',group_rows)
errorrows=[]
for i in order:
 if not wrong[i]:continue
 errorrows.append(dict(id=ids[i],fold=int(fold[i]),label=int(y[i]),probability=float(p[i]),row_loss=float(loss[i]),confident_wrong=bool(confwrong[i]),angle=float(angle[i]) if np.isfinite(angle[i]) else '',nearest_outer_train_angle_distance=float(dist[i]) if np.isfinite(dist[i]) else ''))
savecsv('version19_errors.csv',errorrows)

# Execute only the inspected pure numerical functions, never the bundle entry points.
ns={'np':np,'SIGMA':.012,'ALPHA':.1}
for file,names in [('work/v5_fuse.py',['kernel_prior','logit','sigmoid','fit_logistic','apply_logistic']),('work/v5_greedy.py',['build_prior'])]:
 tree=ast.parse((B/'05_code'/file).read_text(encoding='utf-8'))
 funcs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names]
 exec(compile(ast.Module(body=funcs,type_ignores=[]),file,'exec'),ns)
reconstructed_prior,reconstructed_ex=ns['build_prior'](angle,y,fold)
prior_delta=float(np.max(np.abs(reconstructed_prior-pr)))
assert prior_delta<6e-9 and np.array_equal(reconstructed_ex,ex)
features=np.column_stack([ns['logit'](ip),ns['logit'](reconstructed_prior)*ex,ns['logit'](reconstructed_prior)*(~ex)])
replay=np.zeros(n)
for k in range(5):
 w=ns['fit_logistic'](features[fold!=k],y[fold!=k]);w[1:3]*=.9
 replay[fold==k]=ns['apply_logistic'](features[fold==k],w)
syn_y=np.tile([0.,1.],5);syn_a=np.full(10,40.);syn_f=np.repeat(np.arange(5),2)
before=ns['build_prior'](syn_a,syn_y,syn_f)[0];syn_y[0]=1
after=ns['build_prior'](syn_a,syn_y,syn_f)[0]
weights=ns['fit_logistic'](features,y);weights[1:3]*=.9
checkpoints=[]
for tag in manifest['tags']:
 for k in range(5):
  path=B/'03_weights'/tag/f'fold{k}.pt'
  c=torch.load(path,map_location='cpu',weights_only=True)
  expected=hashlib.sha256('\n'.join(sorted(ids[fold!=k].tolist())).encode()).hexdigest()
  assert c['train_ids_sha256']==expected,(tag,k)
  checkpoints.append(dict(tag=tag,fold=k,sha256=sha(path),training_ids_match=True,architecture=c.get('architecture'),stored_states=len(c.get('states',[]))))
pngs=[]
for f in (B/'06_evidence').glob('*.png'):
 try:
  with Image.open(f) as im:im.verify()
  ok=True
 except Exception:ok=False
 pngs.append(dict(name=f.name,valid_image=ok,header=f.read_bytes()[:8].hex()))
screenshot=Path(r'C:/Users/zhy/AppData/Local/Temp/codex-clipboard-6cbb1bac-8907-4233-ad90-97565c29f52e.png')
shutil.copy2(screenshot,A/'version19_kaggle_receipt.png')
audit=dict(bundle_sha256=sha(Path(r'C:/Users/zhy/Documents/WeChat Files/wxid_01bmfeiczke012/FileStorage/File/2026-11/CS4486_final_bundle.zip')),submission_sha256=manifest['sha256'],submission_rows=len(sub),submission_ids_order_match=True,submission_min=float(sp.min()),submission_max=float(sp.max()),submission_mean=float(sp.mean()),oof_label_fold_angle_checks_passed=True,raw_train_hash_match=True,fold_file_hash_match=fold_hash_match,fold_file_lf_hash_match=fold_lf_hash_match,actual_fold_file_sha256=sha(B/'04_configs/folds.csv'),final_checkpoints=checkpoints,teacher_prediction_files=len(list((B/'03_weights/teachers').rglob('*predictions.npz'))),member_prediction_cache_files=len(list((B/'03_weights').glob('*/*predictions.npz'))),prior_reconstruction_max_error=prior_delta,combiner_reconstruction_max_error=float(np.max(np.abs(replay-p))),manifest_coefficient_max_error=float(np.max(np.abs(weights-np.array(manifest['coefficients'])))),synthetic_validation_prior_before=float(before[1]),synthetic_validation_prior_after=float(after[1]),bundle_evidence_images=pngs,new_receipt_sha256=sha(screenshot),kaggle_private=.08708,kaggle_public=.10724,score_evidence='User supplied image showing filename version19.csv and matching score pair; column headings are cropped; identities follow team records. No platform hash proof.',full_inference_replay_performed=False,reproduction_gaps=['Per-member validation/test prediction caches are absent.','v5_predict.py CNN-only fallback cannot load shape_mlp checkpoint; it expects dropout/state_dict.','Source export includes uncommitted changes; use file hashes rather than commit alone.'],validation_caveat='Supplied prior exactly matches shared-array overwrite implementation; synthetic label perturbation confirms leakage. OOF values are descriptive development diagnostics.')
dump('version19_bundle_audit.json',audit)
savecsv('version19_bundle_inventory.csv',[dict(path=str(f.relative_to(B)).replace('\\','/'),bytes=f.stat().st_size,sha256=sha(f)) for f in B.rglob('*') if f.is_file()])

plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(9,3),layout='constrained')
for a,key,lab in [(ax[0],'log_loss','Log Loss'),(ax[1],'loss_share','Share of total loss (%)')]:
 vals=[g[key]*(100 if key=='loss_share' else 1) for g in group_rows]
 bars=a.bar(list(groups),vals,color=['#52788d','#b46843','#7b8790','#adb7bc']);a.set_ylabel(lab);a.set_ylim(0,max(vals)*1.22)
 for b,v in zip(bars,vals):a.text(b.get_x()+b.get_width()/2,b.get_height()+max(vals)*.03,f'{v:.3f}' if key=='log_loss' else f'{v:.1f}',ha='center')
fig.savefig(A/'version19_error_groups.pdf');plt.close(fig)
fig,axes=plt.subplots(3,2,figsize=(7,7),layout='constrained')
for ax,i in zip(axes.flat,[i for i in order if wrong[i]][:6]):
 r=raw[ids[i]];im=np.concatenate([np.array(r['band_1']).reshape(75,75),np.array(r['band_2']).reshape(75,75)],axis=1)
 lo,hi=np.percentile(im,[2,98]);ax.imshow(im,cmap='gray',vmin=lo,vmax=hi);ax.axis('off')
 ax.set_title(f"{ids[i]} | true: {'iceberg' if y[i] else 'ship'}\np(iceberg)={p[i]:.4f}; fold={fold[i]}; loss={loss[i]:.2f}",fontsize=9)
fig.savefig(A/'version19_largest_errors.png',dpi=180);plt.close(fig)
print(json.dumps(metrics,indent=2));print('AUDIT',json.dumps({k:v for k,v in audit.items() if k!='final_checkpoints'},indent=2))
